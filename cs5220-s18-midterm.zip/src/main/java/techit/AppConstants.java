package techit;

public class AppConstants {
	public static final String JWT_PREFIX = "Bearer ";
	public static final String JWT_SECRET = "secret";
}
