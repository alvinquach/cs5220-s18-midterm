drop table updates;
drop table ticket_technicians;
drop table tickets;
drop table unit_technicians;
drop table unit_supervisors;
drop table users;
drop table units;
drop table hibernate_sequence;
